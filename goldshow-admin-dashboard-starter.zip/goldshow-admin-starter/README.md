# GoldShow Member Platform — Starter

## Features
- Home, My Products, My Profile, Rewards, Transactions, Contact Admin, About, and Admin Dashboard
- Seven VIP price/duration cards:
  - VIP 1: K50, 365 days
  - VIP 2: K150, 365 days
  - VIP 3: K250, 730 days
  - VIP 4: K360, 730 days
  - VIP 5: K500, 1,095 days
  - VIP 6: K1,000, 1,095 days
  - VIP 7: K3,800, 1,095 days
- Copyable demo referral code/link, demo invite count, daily demo points, demo wheel
- Receipt submission queue and review buttons for demonstration
- Local announcement editor and pop-up
- WhatsApp support link and Telegram placeholder
- Capacitor configuration for a later Android build

## Critical prototype limitations
Everything is front-end/local-browser only. Admin tools are not authenticated, data does not sync between devices, receipt files are not uploaded, and no admin notifications are sent. Never use this version to accept deposits or claim receipt verification. No real cash rewards, fixed daily income, guaranteed profit, or referral commission is active.

A live system needs a secure backend/database, real administrator authentication and roles, secure file uploads, server-side receipt review, audit logs, backups, rate limits, privacy controls, and a supported payment arrangement. Never collect BSP PINs, banking passwords, or OTPs. Verify account ownership and obtain suitable Papua New Guinea legal/accounting advice before accepting payments or offering rewards. Be transparent about the product being sold and do not promise guaranteed returns.

## Run locally on a computer
Install Node.js LTS:
```bash
npm install
npm run start
```

## Website deployment
Import this repository into Netlify or Vercel:
- Build command: `npm run build`
- Output directory: `dist`

For GitHub Pages, configure a workflow to build and publish `dist`, and set Vite's base path correctly for a repository subpath.

## Android APK
A computer with Node.js and Android Studio is normally needed:
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Then build the APK in Android Studio. Keep signing keys private and test before distributing.

## Customize
- VIP prices/durations: `app.js`, `tiers`
- WhatsApp: `index.html`, search `wa.me`
- Telegram: replace the placeholder URL with your official public Telegram link
- Bank details: configure only after verifying ownership and implementing a secure backend/payment workflow.
